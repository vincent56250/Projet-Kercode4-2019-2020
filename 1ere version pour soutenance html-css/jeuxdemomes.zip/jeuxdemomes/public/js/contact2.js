//------------------prenom--------------------------
let formValid = document.getElementById('btnEnvoi');
let prenom = document.getElementById('prenom');
let missPrenom = document.getElementById('missPrenom');
// /^=debut de la regexp - $/ fin de la regexp
const prenomValid = /^[a-zA-ZéèîïÉÈÎÏ]{2,}[a-zéèêàçîï]+([-'\s][a-zA-ZéèîïÉÈÎÏ][a-zéèêàçîï]+)?$/
// ---------------nom-----------------------------------
let nom = document.getElementById('nom');
let noName = document.getElementById('noName');
const nomValid = /^[a-zA-ZéèîïÉÈÎÏ]{2,}[a-zéèêàçîï]+([-'\s][a-zA-ZéèîïÉÈÎÏ][a-zéèêàçîï]+)?$/
//----------mail-------------------------------------
let mail = document.getElementById('email');
let noMail = document.getElementById('noMail');
const mailValid =  /^[a-zA-Z0-9._-]+@[a-z0-9._-]{2,}\.[.com|.fr][a-z]{2,4}$/;
//----------------------tel---------------------------
let tel = document.getElementById('tel');
let noTel = document.getElementById('noTel');
const telValid = /^(0|\+33)[1-9]([-. ]?[0-9]{2}){4}$/;
//--------------------------btn d'envoie-------------------------------
formValid.addEventListener('click', validation);
//-----------------fonction-prenom--------------------------
function validation(event) {
    //Si le champ est vide
    if (prenom.validity.valueMissing) {
        /*"preventDefault()"" est une méthode de l’objet "Event" qui va annuler 
        *le déclenchemnt d’un évènement si celui-ci est annulable.*/
        event.preventDefault();
        // ".textContent"= c'est pour allez remplir la balise span
        missPrenom.textContent = 'Prénom manquant';
        missPrenom.style.color = 'red'; 
        console.log('champ vide prenom')
        //Si le format de données est incorrect       
    } else if (prenomValid.test(prenom.value) == false) {
        event.preventDefault();
        missPrenom.textContent = 'Format incorrect';
        missPrenom.style.color = 'orange';
        console.log('format incorrect prenom')
    } else {
        missPrenom.style.color = 'green';
        console.log('ok')}
}
// -----------fonction----nom-------------------------------
function validation(event) {
    //Si le champ est vide
    if (nom.validity.valueMissing) {    
        event.preventDefault();
        noName.textContent = 'nom manquant';
        noName.style.color = 'red';
        console.log('champ vide nom')
        //Si le format de données est incorrect
    } else if (nomValid.test(nom.value) == false) {
        event.preventDefault();
        noName.textContent = 'Format incorrect';
        noName.style.color = 'orange';
        console.log('format incorrect nom')
    } else {
        noName.style.color = 'green';
        console.log('ok')}
}
//----------fonction-------mail-------------------------------
function validation(event) {
    //Si le champ est vide
    if (mail.validity.valueMissing) {
        event.preventDefault();
        noMail.textContent = 'Mail manquant';
        noMail.style.color = 'red';
        console.log('champ vide mail')
        //Si le format de données est incorrect
    } else if (mailValid.test(mail.value) == false) {
        event.preventDefault();
        noMail.textContent = 'Format incorrect';
        noMail.style.color = 'orange';
        console.log('format incorrect mail')
    } else {
        noMail.style.color = 'green';
        console.log('ok')}
}
//----------fonction----tel--------------
function validation(event) {
    //Si le champ est vide
    if (tel.validity.valueMissing) {
        event.preventDefault();
        noTel.textContent = 'tel manquant';
        noTel.style.color = 'red';
        console.log('champ vide tel')
        //Si le format de données est incorrect
    } else if (telValid.test(tel.value) == false) {
        event.preventDefault();
        noTel.textContent = 'Format incorrect';
       noTel.style.color = 'orange';
       console.log('format incorrect tel')
    } else {
        noTel.style.color = 'green';
        console.log('ok')
    }
}