/*let i=0
*let active = document.getElementById("menu");
*menus.addEventListener('click', function(menu){
 *   menu.innerHtml = document.getElementsByClassName("active");  
 *   element.classList.toggle("active");
*      console.log('active')
})*/
 //fonction class Active

// //Add active class to the current button (highlight it)
// // var header = document.getElementById("myMENU");
// // var menus = header.getElementsByClassName("menu");
// // for (var i = 0; i < menus.length; i++) {
// //   menus[i].addEventListener("click", function() {
// //   var current = document.getElementsByClassName("active");
 document.getElementById("monElement").className += "active";
 //declarer une variable ou une fonction et faire une boucle
 //http://www.trucsweb.com/tutoriels/javascript/css-classname/